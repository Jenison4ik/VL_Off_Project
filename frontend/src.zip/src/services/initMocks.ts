// export async function initMocks() {
//   if (typeof window === "undefined") {
//     const { server } = await import("../mocks/node.js");
//     server.listen();
//   } else {
//     const { worker } = await import("../mocks/browser.js");
//     await worker.start();
//   }
// }
