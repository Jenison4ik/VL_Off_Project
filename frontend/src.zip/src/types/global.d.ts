export {};

declare global {
  interface Window {
    ymaps3: any;
  }
}
