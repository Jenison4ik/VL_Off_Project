export default interface adresses {
  id: number;
  street: string;
  city: string;
}
