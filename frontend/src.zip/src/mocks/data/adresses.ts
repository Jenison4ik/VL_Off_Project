import AdressesType from "../../types/adresses";

export const adresses: AdressesType[] = [
  { id: 1, street: "Западная, 1", city: "Владивосток" },
  { id: 2, street: "Калинина, 5", city: "Владивосток" },
  { id: 3, street: "Суханова, 12", city: "Владивосток" },
  { id: 4, street: "Алеутская, 8", city: "Владивосток" },
  { id: 5, street: "Фонтанная, 21", city: "Владивосток" },
];
